var persom = {
    name:"nebil",
    lastname:"gokdemir",
    age:28
}
console.log(persom.name);